# Utils package for KDI Smart Platform

